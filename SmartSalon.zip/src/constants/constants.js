export const defaultServices = ["Color", "Haircutting", "Makeup", "Waxing"];
export const time = [
  "10AM to 11AM",
  "11AM to 12PM",
  "12PM to 13PM",
  "13PM to 14PM",
  "15PM to 16PM",
  "16PM to 17PM",
  "17PM to 18PM",
];