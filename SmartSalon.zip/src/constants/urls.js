export const deleteAppointmentUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/appoinments/';
export const addUserDataUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/userData.json';
export const fetchUserDataUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/userData.json';
export const updateUserDataUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/';
export const createAppointmentsUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/appoinments.json?key=';
export const fetchAppointmentsUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/appoinments.json';
export const fetchServicesUrl = 'https://react-beauty-salon-cacbe-725da-default-rtdb.firebaseio.com/fetchServicesUrl.json';
export const signInUrl = 'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyD1VgqGAvCUavGM-9NskJmlb-Ms-zcF-eA';
export const signUpUrl = 'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyD1VgqGAvCUavGM-9NskJmlb-Ms-zcF-eA';

